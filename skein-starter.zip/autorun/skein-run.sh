#!/usr/bin/env bash
# skein-run.sh — one self-contained task runner for Skein.
#
# Loop: pick first unchecked task in TASKS.md → fresh headless Claude session for
# that ONE task (spec-referenced) → session must end with tests green + a commit
# → runner verifies independently → prints progress + token/cost per task → next.
#
# Usage:   ./skein-run.sh            # run until TASKS.md is done
#          ./skein-run.sh 3         # run at most 3 tasks
#          DRY=1 ./skein-run.sh     # show next task + prompt, don't run
#
# Expects at repo root: CLAUDE.md, feature-spec.md, skein-phases.md,
# react-migration.md, TASKS.md. Run inside a container/VM (skips permissions).

set -euo pipefail
MAX="${1:-999}"
command -v claude >/dev/null || { echo "claude CLI not found (npm i -g @anthropic-ai/claude-code)"; exit 1; }
command -v jq >/dev/null || { echo "jq required for token reporting (apt/brew install jq)"; exit 1; }
for f in TASKS.md feature-spec.md skein-phases.md react-migration.md CLAUDE.md; do
  [ -f "$f" ] || { echo "Missing $f in $(pwd)"; exit 1; }
done

TOTAL_IN=0; TOTAL_OUT=0; TOTAL_COST=0; DONE_COUNT=0
START_TS=$(date +%s)

progress() {
  local done total
  done=$(grep -c '^\- \[x\]' TASKS.md || true)
  total=$(grep -c '^\- \[' TASKS.md || true)
  echo "── progress: $done/$total tasks · session tokens in=$TOTAL_IN out=$TOTAL_OUT · cost \$$TOTAL_COST · $((($(date +%s)-START_TS)/60))m elapsed"
}

for i in $(seq 1 "$MAX"); do
  TASK=$(grep -m1 '^\- \[ \]' TASKS.md | sed 's/^- \[ \] //' || true)
  if [ -z "${TASK:-}" ]; then echo "✅ All tasks in TASKS.md complete."; progress; exit 0; fi
  TID=$(echo "$TASK" | awk '{print $1}')

  echo ""
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "▶ Task $i: $TASK"
  progress

  PROMPT="Read CLAUDE.md, react-migration.md, skein-phases.md, and feature-spec.md.
We are executing TASKS.md task '$TID' and NOTHING else: $TASK
Steps you MUST follow, in order:
1. Locate this task's numbered development prompt in feature-spec.md (match the T-number) and the relevant feature sections + sketches; QUOTE the spec lines you are implementing before writing code.
2. Respect every invariant in CLAUDE.md and every rule in react-migration.md (cite file:line for claims about existing code; check lockfile versions).
3. Implement the task. Do not touch code belonging to other tasks. Stub cross-task joints and note them in the commit body.
4. Verify: run the test suite (npm test) and, if this task has UI, the smoke check. Fix until green.
5. Commit everything as: '$TID: <one-line summary>' with a body listing spec lines implemented + any stubs.
6. Edit TASKS.md: change this task's '- [ ]' to '- [x]' and amend it into the same commit.
7. Stop. Do not begin the next task."

  if [ "${DRY:-0}" = "1" ]; then echo "$PROMPT"; exit 0; fi

  HEAD_BEFORE=$(git rev-parse HEAD 2>/dev/null || echo none)

  # Fresh session per task = clean context. JSON output gives us usage numbers.
  set +e
  RESULT=$(claude -p --dangerously-skip-permissions --output-format json "$PROMPT" 2>&1)
  RC=$?
  set -e

  # ── token / cost report (fields per current CLI; fall back gracefully)
  IN=$( echo "$RESULT" | jq -r '.usage.input_tokens  // .usage.inputTokens  // 0' 2>/dev/null || echo 0)
  OUT=$(echo "$RESULT" | jq -r '.usage.output_tokens // .usage.outputTokens // 0' 2>/dev/null || echo 0)
  COST=$(echo "$RESULT" | jq -r '.total_cost_usd // .cost_usd // 0' 2>/dev/null || echo 0)
  TURNS=$(echo "$RESULT" | jq -r '.num_turns // "?"' 2>/dev/null || echo "?")
  TOTAL_IN=$((TOTAL_IN+IN)); TOTAL_OUT=$((TOTAL_OUT+OUT))
  TOTAL_COST=$(python3 -c "print(round($TOTAL_COST+$COST,4))")
  echo "  tokens: in=$IN out=$OUT · turns=$TURNS · cost \$$COST"

  # ── independent verification (never trust the session's own claim)
  FAIL=""
  [ $RC -ne 0 ] && FAIL="claude exited rc=$RC"
  if [ -z "$FAIL" ] && [ "$(git rev-parse HEAD)" = "$HEAD_BEFORE" ]; then FAIL="no commit was made"; fi
  if [ -z "$FAIL" ] && [ -n "$(git status --porcelain)" ]; then FAIL="uncommitted changes left behind"; fi
  if [ -z "$FAIL" ] && ! npm test --silent >/dev/null 2>&1; then FAIL="tests failing post-commit"; fi
  if [ -z "$FAIL" ] && grep -qF -- "- [ ] $TASK" TASKS.md; then FAIL="task not ticked in TASKS.md"; fi

  if [ -n "$FAIL" ]; then
    echo "✖ Task $TID FAILED verification: $FAIL"
    echo "  Last session output tail:"; echo "$RESULT" | jq -r '.result // .' 2>/dev/null | tail -5
    echo "  Stopping for human review. Re-run ./skein-run.sh after fixing."
    exit 1
  fi

  DONE_COUNT=$((DONE_COUNT+1))
  echo "✔ $TID verified: committed $(git log -1 --format=%h) · tests green · ticked"
done

echo ""; echo "Reached max ($MAX) tasks this run."; progress
